<?php

namespace App\Http\Controllers\soporte;

use App\Http\Controllers\Controller;
use App\Models\Cliente\Provincia;
use Illuminate\Http\Request;

class ProvinciaController extends Controller
{
 
}
