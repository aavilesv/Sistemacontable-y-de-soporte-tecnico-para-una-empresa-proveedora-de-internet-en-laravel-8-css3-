<?php

namespace App\Models\recursoshumanos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rrharea extends Model
{
    use HasFactory;
}
